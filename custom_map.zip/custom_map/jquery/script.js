
//$(document).ready(function () {});



//alert('Bismillah');

//$(document).ready(function () {
//    $('#selectable').selectable();
//});
//
//

//$('div').on('click',function(){
//   $('div').removeClass('active');
//    $(this).addClass('active');
//});


//$(function{
//    
//})


//$(document).ready(function () {
//    $('#div img').hover(
//            function () {
//                $(this).animate({'zoom': 1.2}, 400);
//            },
//            function () {
//                $(this).animate({'zoom': 1}, 400);
//            });
//});






//$('input[type="checkbox"]').button({
//    icons: {
////        primary: 'ui-icon-circle-triangle-w',
////        secondary: 'ui-icon-circle-triangle-e'
//    }
//});
//
//
//$('input[type="radio"], button, a').button({
//    icons: {
//        primary: 'ui-icon-circle-triangle-w',
//        secondary: 'ui-icon-circle-triangle-e'
//    }
//});







