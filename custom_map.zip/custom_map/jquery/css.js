$(document).ready(function () {

});

$("nav div a").addClass("text_decoration");