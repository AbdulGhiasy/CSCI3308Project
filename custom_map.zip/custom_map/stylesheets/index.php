<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

    <head>
        <title>Custom_Map</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">



        <link href="stylesheets/layouts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/responsive.css" rel="stylesheet" type="text/css"/>
      
        <link href="stylesheets/fonts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/defaults.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">   
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">
        <link href="stylesheets/layouts.php" rel="stylesheet" type="text/css"/>
        

    </head>
    <body>



        <div class="button_menu">


            <input type="checkbox" id="Starting_point" name="location"><label for="Starting_point">Starting_point</label>
            <input type="checkbox" id="Destination_point" name="location"><label for="Destination_point">Destination Point</label>
            <button>button</button>


        </div>


        <div class="map_div"  id="div">

<!--            <img src="Images/map.jpg" id="img"alt=""/>-->


            <div id="img"> Builing #25 </div>
            <div id="img2"> Road Central </div>
            <div id="img3"> 1232Mark</div>
            <div id="img4"> Exit 545646 Road </div>


<!--            <img src="http://www.wallpaper4me.com/images/wallpapers/batmobileblueprintstop-558218.jpeg"  id="draggable img" />-->



        </div>

        <div id="nav">
            <!--            <button>Zoom (+)</button>
                        <button>Zoom (-)</button>-->
            <input type="button" value="Zoom (+)" />
            <input type="button" value="Zoom (-)" />

        </div>
        <div class="footer">

        </div>


    </body>
    <script src="jquery/jquery-3.1.1.js" type="text/javascript"></script>
<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
    <script src="jquery/jquery-ui-1.12.1.custom/jquery-ui.min.js" type="text/javascript"></script>
    <script src="jquery/script.js" type="text/javascript"></script>






</body>
</html>

