<?php
$data = $_REQUEST['imageData'];
						
list($type, $data2) = explode(';', $data);
$img = $_REQUEST['imageData'];

$img = str_replace('data:image/png;base64,', '', $img);
$img = str_replace(' ', '+', $img);
$data = base64_decode($img);
$fname = uniqid().rand() . '.png';
$file = './image/' . $fname;
$success = file_put_contents($file, $data);
echo $fname;
?>
