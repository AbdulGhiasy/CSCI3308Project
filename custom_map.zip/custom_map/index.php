<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

    <head>
        <title>Custom_Map</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="stylesheets/layouts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/responsive.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/fonts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/defaults.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">   
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link href="stylesheets/layouts.php" rel="stylesheet" type="text/css"/>

    </head>
    <body>



        <div class="button_menu">
            <div class="nav_wrapper">
                <input type="radio" id="Starting_point" name="location" ><label id="startingLabel" for="Starting_point">Starting Point</label>
                <input type="radio" id="Destination_point" name="location" ><label id="destinationLabel" for="Destination_point">Destination point</label>
                <input type="radio" id="draw_route" name="location" ><label id="draw_routeLabel" for="draw_route">Draw Route</label>
                <a href="javascript:getScreenshot()"> Get Screenshot</a>
                <input type="button" value="Remove All Locations"  id="resetAll"/>
                <span id="zoomin-out">
                    <input type="button" value="Zoom(+)"  id="zoomin"/>
                    <input type="button" value="Zoom(-)"  id="zoomout"/>
                </span>
                <div class="instruction"></div>
            </div>
        </div>




        <div class="map_div"  id="div">


    
            <canvas  id="canvas" height="510" width="990"></canvas>

            <div id="box1">
                <canvas></canvas>
            </div>

            <!--            <div class="compass">
                            <img src="graphics/compass-2.jpg" alt=""/>
                        </div>-->

            <div class="map_con" id="mapcon" usemap="#planetmap">

                <map name="planetmap" id="mapsection">
                    <div class="me you co-ordinates_Alum"                              id="Alum" ></div>
                    <div class="me you co-ordinates_EKLC"                              id="EKLC"></div>
                    <div class="me you co-ordinates_FRANKLIN-FIELD"     id="FRANKLIN-FIELD"></div>
                    <div class="me you co-ordinates_FARRAND-FIELD"      id="FARRAND-FIELD"></div>
                </map>   
            </div>

        </div>


        <div class="footer">
            <div >
                <form action="submit.php" id="locationSubmissionForm" method="post">
                    <input type="text"          placeholder="Starting Point"                        value=""         id="startingpointval"                          name="statingLocation"                          required="" />
                    <input type="text"          placeholder="Destination Point"                 value=""         id="endingpointval"                  name="endingLocation"                            required="" />
                    <input type="submit"    value="Submit Location"                                id="resetAll"/>
                </form>
            </div>
            <div>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
                    dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with 
                    desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </p>
            </div>
        </div>

    </body>
    <script src="jquery/jquery-3.1.1.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="jquery/jquery-ui-1.12.1.custom/jquery-ui.min.js" type="text/javascript"></script>
    <script src="jquery/html2canvas.svg.js" type="text/javascript"></script>
    <script src="jquery/script.js" type="text/javascript"></script>







</html>
<script>


    function getScreenshot() {
//        html2canvas(document.body,{
//            onrendered: function (canvas) {
//                
//                $('#box1').append(canvas);
//                $('#box1 canvas').css({
//                    'height': '70px',
//                    'width': '100px',
//                    'margin-left': '100px',
//                    
//                });
//                
//
//            }
//        });


        html2canvas(document.body, {
            onrendered: function (canvas) {
                $('#box1').append(canvas);
            }
        });


    }




    $('#startingpointval,#endingpointval').change(function () {
        alert('Manual typing restriction please use above menu to select position');

        /* Single line Reset function executes on click of Reset Button */
        $("#locationSubmissionForm")[0].reset();
    });







 










    $(function () {
        $("#div1").draggable();
        $("#div2").draggable();
        $("#div3").draggable();
        $("#div4").draggable();
//        $("#mapcon").draggable({
//            containment: "#div"
//        });

    });



//    $('input[type="radio"]').button().click(function () {
//        var isChecked = $(this).is(':checked') ? 'Checked' : 'Unchecked';
//        alert($(this).attr('id') + ' radio ' + isChecked);
//    });
//    







    $(document).ready(function () {
        $(".me").each(function () {
            $(this).click('click', function () {
                if ($("#Starting_point").prop("checked") === true) {
                    if ($(this).hasClass('blue')) {
                    } else {
                        $(".me").removeClass('red');
                        $('.me span.startingpoint').remove();
                        $(this).addClass('red');
                        $(this).append('<span class="startingpoint"><img src="graphics/landmark.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#startingpointval").val(str);

                    }
                }
            });
        });
        $(".you").each(function () {
            $(this).click(function () {
                if ($("#Destination_point").prop("checked") === true) {
                    if ($(this).hasClass('red')) {
                    } else {
                        $(".me").removeClass('blue');
                        $('.me span.endingpoint').remove();
                        $(this).addClass('blue');
                        $(this).append('<span class="endingpoint"><img src="graphics/flag.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#endingpointval").val(str);


                    }
                }
            });

        });
    });








    $(document).ready(function () {
        $(".me").each(function () {
            $(this).click('click', function () {
                if ($("#draw_route").prop("checked") === true) {
                    if ($(this).hasClass('blue')) {
                    } else {
                        $(".me").removeClass('red');
                        $('.me span.startingpoint').remove();
                        $(this).addClass('red');
                        $(this).append('<span class="startingpoint"><img src="graphics/landmark.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#startingpointval").val(str);

                    }
                }
            });
        });
        $(".you").each(function () {
            $(this).click(function () {
                if ($("#Destination_point").prop("checked") === true) {
                    if ($(this).hasClass('red')) {
                    } else {
                        $(".me").removeClass('blue');
                        $('.me span.endingpoint').remove();
                        $(this).addClass('blue');
                        $(this).append('<span class="endingpoint"><img src="graphics/flag.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#endingpointval").val(str);


                    }
                }
            });

        });
    });



















    $(document).ready(function () {
        $('#resetAll').click(function () {

//            $('.map_div div').removeClass("red blue");
            $('#mapsection div').removeClass("red blue");
            $('.me span.startingpoint').remove();
            $('.me span.endingpoint').remove();
            window.location.href = window.location.href + "";

            $('input[name=location]').prop('checked', false);
            $('input[name=location]').removeClass('ui-state-focus');
            $("input[name=location]").buttonset("refresh");
            $("#img").load(location.href + " #mydiv");
        });
    });



    $(document).ready(function () {

        $("#startingLabel")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Select the Starting Point</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });


        $("#destinationLabel")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Select the Destination Point</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $("#resetAll")
                .mouseover(function () {
                    $('.instruction').append('<span>Reset all the selected Locations</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $("#zoomin")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Zoom In map</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });


        $("#zoomout")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Zoom Out map</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $(".map_con")
                .mouseenter(function () {

                    $('.instruction').one().append('<span>It is dragable map </span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

    });



    $(this).click('click', function () {
        if ($("#draw_route").prop("checked") === true) {
            if ($(this).hasClass('none')) {

            } else {
                $('#canvas').css({
                    'z-index': '11',
                    'border': '0.5px dotted aqua'
                });
            }
        } else {
            $('#canvas').css({
                'z-index': '-1',
                'border': ''
            });
        }
    });






    var canvas,
            context,
            dragStartLocation,
            snapshot;


    function getCanvasCoordinates(event) {
        var x = event.clientX - canvas.getBoundingClientRect().left,
                y = event.clientY - canvas.getBoundingClientRect().top;

        return {x: x, y: y};
    }

    function takeSnapshot() {
        snapshot = context.getImageData(0, 0, canvas.width, canvas.height);
    }

    function restoreSnapshot() {
        context.putImageData(snapshot, 0, 0);
    }


    function drawLine(position) {
        context.beginPath();
        context.moveTo(dragStartLocation.x, dragStartLocation.y);
        context.lineTo(position.x, position.y);
        context.stroke();
    }

    function dragStart(event) {
        dragging = true;
        dragStartLocation = getCanvasCoordinates(event);
        takeSnapshot();
    }

    function drag(event) {
        var position;
        if (dragging === true) {
            restoreSnapshot();
            position = getCanvasCoordinates(event);
            drawLine(position);
        }
    }

    function dragStop(event) {
        dragging = false;
        restoreSnapshot();
        var position = getCanvasCoordinates(event);
        drawLine(position);
    }

    function init() {
        canvas = document.getElementById("canvas");
        context = canvas.getContext('2d');
        context.strokeStyle = 'red';
        context.lineWidth = 10;
        context.lineCap = 'round';

        canvas.addEventListener('mousedown', dragStart, false);
        canvas.addEventListener('mousemove', drag, false);
        canvas.addEventListener('mouseup', dragStop, false);
    }

    window.addEventListener('load', init, false);


</script>
