<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

    <head>
        <title>Custom_Map</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="stylesheets/layouts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/responsive.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/fonts.css" rel="stylesheet" type="text/css"/>
        <link href="stylesheets/defaults.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">   
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link rel="stylesheet" href="/resources/demos/style.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link href="stylesheets/layouts.php" rel="stylesheet" type="text/css"/>

    </head>
    <body>



        <div class="button_menu">
            <div class="nav_wrapper">
                <input type="radio" id="Starting_point" name="location" ><label id="startingLabel" for="Starting_point">Starting Point</label>
                <input type="radio" id="Destination_point" name="location" ><label id="destinationLabel" for="Destination_point">Destination point</label>
                <input type="radio" id="draw_route" name="location" ><label id="draw_routeLabel" for="draw_route">Draw Route</label>


                <a href="javascript:genScreenshot()" 

                   id="screen_shoot"

                   style="
                   text-decoration: none;
                   /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#131313+0,4c4c4c+65,4c4c4c+100 */
                   /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#131313+0,3f3f3f+100 */
                   background: rgb(19,19,19); /* Old browsers */
                   background: -moz-linear-gradient(top, rgba(19,19,19,1) 0%, rgba(63,63,63,1) 100%); /* FF3.6-15 */
                   background: -webkit-linear-gradient(top, rgba(19,19,19,1) 0%,rgba(63,63,63,1) 100%); /* Chrome10-25,Safari5.1-6 */
                   background: linear-gradient(to bottom, rgba(19,19,19,1) 0%,rgba(63,63,63,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
                   filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#131313', endColorstr='#3f3f3f',GradientType=0 ); /* IE6-9 */

                   font-family: 'bold';
                   font-size: 12px;


                   padding:  18px 30px;

                   text-align: center;
                   line-height: 49px;
                   color: #eee;

                   "
                   > Get Screenshot</a>

                <input type="button" value="Remove All Locations"  id="resetAll"/>
                    <!--<span id="zoomin-out">
                    <input type="button" value="Zoom(+)"  id="zoomin"/>
                    <input type="button" value="Zoom(-)"  id="zoomout"/>
                </span>-->
                <div class="instruction"></div>
            </div>
        </div>






        <div class="map_div"  id="img">
            <div id="box1"></div>
            <div class="compass"><img src="graphics/compass-2.jpg" alt=""/></div>





            <div class="map_con" id="mapcon" usemap="#planetmap" >


                <p class="canvas_wrapper" style="position: absolute;left: 0px; height: 98.2%; width: 97%;">
                    <canvas  id="canvas2" class="canvas" height="530" width="1000" align="center"></canvas>
                </p>


                <map name="planetmap" id="mapsection">
                    <div class="me you co-ordinates_Alum"                              id="Alum" ></div>
                    <div class="me you co-ordinates_EKLC"                              id="EKLC"></div>
                    <div class="me you co-ordinates_FRANKLIN-FIELD"     id="FRANKLIN-FIELD"></div>
                    <div class="me you co-ordinates_FARRAND-FIELD"      id="FARRAND-FIELD"></div>
                    <!--                    UMC C4C EC REC and LIBR-->

                    <div class="me you co-ordinates_UMC"      id="UMC"></div>
                    <div class="me you co-ordinates_C4c"      id="C4c"></div>
                    <div class="me you co-ordinates_REC"      id="REC"></div>
                    <div class="me you co-ordinates_LIBR"      id="LIBR"></div>


                </map>   
            </div>
        </div>

        <div class="footer">
            <div >
                <form action="submit.php" id="locationSubmissionForm" method="post">
                    <input type="text" placeholder="Image Name"     name="getimgname" id="getimgname">
                    <a id="test"></a>
                    <input type="text"          placeholder="Starting Point"                        value=""         id="startingpointval"                          name="statingLocation"                          required="" />
                    <input type="text"          placeholder="Destination Point"                 value=""         id="endingpointval"                  name="endingLocation"                            required="" />
                    <input type="submit"    value="Submit Location"                                id="resetAll"/>
                </form>
            </div>
            <div>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
                    dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with 
                    desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </p>
            </div>
        </div>

    </body>


    <script src="jquery/jquery-ui-1.12.1.custom/jquery-ui.min.js" type="text/javascript"></script>
    <script src="jquery/jquery-3.1.1.js" type="text/javascript"></script>
    <script src="https://rawgit.com/niklasvh/html2canvas/master/dist/html2canvas.min.js"></script>





</html>
<script>





    function genScreenshot() {
       html2canvas(document.body, {
            onrendered: function (canvas) {
                $('#box1').html("");
                $('#box1').append(canvas);

                if (navigator.userAgent.indexOf("MSIE ") > 0 ||
                        navigator.userAgent.match(/Trident.*rv\:11\./))
                {
                    var blob = canvas.msToBlob();
                    window.navigator.msSaveBlob(blob, 'Test file.png');
                } else {
                    var imglink = canvas.toDataURL("image/png")
                

                    if (imglink != '') {
                        $.ajax({
                            url: 'saveimg.php',
                            data: 'imageData=' + imglink,
                            type: 'post',
                            success: function (data) {
                                $('#getimgname').val(data);
                            }
                        })
                    }
                }
            }
        });
    }




    $('#startingpointval,#endingpointval').change(function () {
        alert('Manual typing restriction please use above menu to select position');

        /* Single line Reset function executes on click of Reset Button */
        $("#locationSubmissionForm")[0].reset();
    });


    $(function () {
        $("#div1").draggable();
        $("#div2").draggable();
        $("#div3").draggable();
        $("#div4").draggable();
//        $("#mapcon").draggable({
//            containment: "#div"
//        });





//    $('input[type="radio"]').button().click(function () {
//        var isChecked = $(this).is(':checked') ? 'Checked' : 'Unchecked';
//        alert($(this).attr('id') + ' radio ' + isChecked);
//    });



    });







    $(document).ready(function () {
        $(".me").each(function () {
            $(this).click('click', function () {
                if ($("#Starting_point").prop("checked") === true) {
                    if ($(this).hasClass('blue')) {
                    } else {
                        $(".me").removeClass('red');
                        $('.me span.startingpoint').remove();
                        $(this).addClass('red');
                        $(this).append('<span class="startingpoint"><img src="graphics/landmark.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#startingpointval").val(str);

                    }
                }
            });
        });
        $(".you").each(function () {
            $(this).click(function () {
                if ($("#Destination_point").prop("checked") === true) {
                    if ($(this).hasClass('red')) {
                    } else {
                        $(".me").removeClass('blue');
                        $('.me span.endingpoint').remove();
                        $(this).addClass('blue');
                        $(this).append('<span class="endingpoint"><img src="graphics/flag.png" alt=""/></span>');

                        var str = $(this).attr('id');
                        $("#endingpointval").val(str);
                        $('#canvas2').css({
                            'border': '1px solid aqua',
                            'z-index': '1'
                        });

                    }
                }
            });

        });
    });





    $('#Starting_point').change(function () {
        if ($("#Starting_point").prop("checked") === true) {
            if ($(this).hasClass('blue')) {
            } else {

                $('#canvas2').css({
                    'border': '',
                    'z-index': '-1'
                });

            }
        }
    });
    $('#Destination_point').change(function () {
        if ($("#Destination_point").prop("checked") === true) {
            if ($(this).hasClass('blue')) {
            } else {

                $('#canvas2').css({
                    'border': '',
                    'z-index': '-1'
                });

            }
        }
    });
    $('#draw_route').change(function () {
        if ($("#draw_route").prop("checked") === true) {
            if ($(this).hasClass('blue')) {
            } else {

                $('#canvas2').css({
                    'border': '1px solid aqua',
                    'z-index': '1'
                });

            }
        }
    });



















    $(document).ready(function () {
        $('#resetAll').click(function () {

//            $('.map_div div').removeClass("red blue");
            $('#mapsection div').removeClass("red blue");
            $('.me span.startingpoint').remove();
            $('.me span.endingpoint').remove();
            window.location.href = window.location.href + "";

            $('input[name=location]').prop('checked', false);
            $('input[name=location]').removeClass('ui-state-focus');
            $("input[name=location]").buttonset("refresh");
            $("#img").load(location.href + " #mydiv");
        });
    });



    $(document).ready(function () {

        $("#startingLabel")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Select the Starting Point</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });


        $("#destinationLabel")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Select the Destination Point</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $("#resetAll")
                .mouseover(function () {
                    $('.instruction').append('<span>Reset all the selected Locations</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $("#zoomin")
                .mouseover(function () {
                    $('.instruction').append('<span>Click to Zoom In map</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });

        $("#draw_routeLabel")
                .mouseover(function () {
                    $('.instruction').append('<span>You can draw a line</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });



        $("#screen_shoot")
                .mouseover(function () {
                    $('.instruction').append('<span>Get a screen shot to save in database</span>');
                })
                .mouseleave(function () {
                    $('.instruction span').remove();
                });



    });










    var canvas2,
            context,
            dragStartLocation,
            snapshot;


    function getCanvasCoordinates(event) {
        var x = event.clientX - canvas2.getBoundingClientRect().left,
                y = event.clientY - canvas2.getBoundingClientRect().top;

        return {x: x, y: y};
    }

    function takeSnapshot() {
        snapshot = context.getImageData(0, 0, canvas2.width, canvas2.height);
    }

    function restoreSnapshot() {
        context.putImageData(snapshot, 0, 0);
    }


    function drawLine(position) {
        context.beginPath();
        context.moveTo(dragStartLocation.x, dragStartLocation.y);
        context.lineTo(position.x, position.y);
        context.stroke();
    }

    function dragStart(event) {
        dragging = true;
        dragStartLocation = getCanvasCoordinates(event);
        takeSnapshot();
    }

    function drag(event) {
        var position;
        if (dragging === true) {
            restoreSnapshot();
            position = getCanvasCoordinates(event);
            drawLine(position);
        }
    }

    function dragStop(event) {
        dragging = false;
        restoreSnapshot();
        var position = getCanvasCoordinates(event);
        drawLine(position);
    }

    function init() {
        canvas2 = document.getElementById("canvas2");
        context = canvas2.getContext('2d');
        context.strokeStyle = 'red';
        context.lineWidth = 5;
        context.lineCap = 'round';

        canvas2.addEventListener('mousedown', dragStart, false);
        canvas2.addEventListener('mousemove', drag, false);
        canvas2.addEventListener('mouseup', dragStop, false);
    }

    window.addEventListener('load', init, false);


</script>
