
<?php

$var_startingpointval = $_POST['statingLocation'];
$var_endingpointval = $_POST['endingLocation'];

$teacher_registration_data = array(
    'post_startingpoint' => $var_startingpointval,
    'post_endingpoint' => $var_endingpointval,
);

$ins_fields = '`' . implode('`, `', array_keys($teacher_registration_data)) . '`';
$ins_values = "'" . implode("', '", ($teacher_registration_data)) . "'";

print_r($ins_fields);
print_r('<br><br>');
print_r($ins_values);

$conn = mysqli_connect("127.0.0.1", "root", "", "custom_map");


if (!$conn) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}


$sql = "INSERT INTO `custom_map`.`MapLocations`($ins_fields) VALUES ($ins_values)";

var_dump($sql);


if ($conn->query($sql) == TRUE) {
         header('location:index.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
        header('location:index.php');
}
$conn->close();

?>

