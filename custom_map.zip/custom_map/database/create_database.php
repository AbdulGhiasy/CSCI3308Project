<?php

$host_name = '127.0.0.1';
$username = 'root';
$password = '';
$data_base = 'custom_map';



$conn = new mysqli($host_name, $username, $password);
$select_db = mysqli_select_db($conn, $data_base);
$create_database = "CREATE DATABASE $data_base";
$create_table = "CREATE TABLE MapLocations (

post_id INT(10) AUTO_INCREMENT PRIMARY KEY, 
post_startingpoint VARCHAR(225),
post_endingpoint VARCHAR(225),
post_locationScreenShot VARCHAR(225)    

)";

if ($select = $select_db) {
    if ($select) {

        echo "Database Created and selected";
        $conn->query($create_table);
    }
} else if ($conn->query($create_database)) {
    mysqli_errno($conn);
//    header("Refresh:0");
};
?>
