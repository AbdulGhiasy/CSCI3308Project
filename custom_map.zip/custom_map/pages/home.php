<div class="width_wrapper">
this is my home page
</div>